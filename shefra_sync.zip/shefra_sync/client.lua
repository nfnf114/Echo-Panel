local QBCore = exports['qb-core']:GetCoreObject()
local lastAppearanceHash = nil

-- Rate limiting: prevent capturing the same player too frequently
local lastScreenshotTime = 0
local SCREENSHOT_COOLDOWN = 200 -- 0.2 seconds minimum between screenshots for live streaming

-- ============================================================
-- GETPEDSHOT - Proven method for headshots
-- ============================================================

local function GetPedShot(ped)
    Wait(0)
    local tempHandle = RegisterPedheadshotTransparent(ped)
    local headshotTxd = nil
    local timer = 2000

    while (not IsPedheadshotReady(tempHandle) or not IsPedheadshotValid(tempHandle)) and timer > 0 do
        Wait(1)
        timer = timer - 10
    end

    headshotTxd = GetPedheadshotTxdString(tempHandle)

    if not headshotTxd or headshotTxd == 0 or not IsPedheadshotValid(tempHandle) then
        UnregisterPedheadshot(tempHandle)
        tempHandle = RegisterPedheadshot_3(ped)
        timer = 2000
        while (not IsPedheadshotReady(tempHandle) or not IsPedheadshotValid(tempHandle)) and timer > 0 do
            Wait(1)
            timer = timer - 10
        end
        headshotTxd = GetPedheadshotTxdString(tempHandle)
    end

    return headshotTxd, tempHandle
end

-- ============================================================
-- CAPTURE CORE
-- ============================================================

local function CaptureFaceSilent()
    local ped = PlayerPedId()
    local pData = QBCore.Functions.GetPlayerData()
    if not pData or not pData.citizenid then return end

    local txd, handle = GetPedShot(ped)
    if not txd or txd == "" then
        if handle then UnregisterPedheadshot(handle) end
        return
    end

    SendNUIMessage({
        action     = 'capture_headshot',
        txd        = txd,
        citizenid  = pData.citizenid,
        backendUrl = Config.BackendURL
    })

    SetTimeout(5000, function()
        if handle then UnregisterPedheadshot(handle) end
    end)
end

-- ============================================================
-- SMART APPEARANCE DETECTOR
-- Checks clothes, hair, face features, and overlays
-- ============================================================

local function GetAppearanceHash()
    local ped = PlayerPedId()
    local hash = ""
    
    -- 1. Clothes (0-11)
    for i = 0, 11 do
        hash = hash .. i .. GetPedDrawableVariation(ped, i) .. GetPedTextureVariation(ped, i)
    end
    
    -- 2. Head Overlays (Beard, Skin, Aging, Makeup, etc.)
    for i = 0, 12 do
        local _, index, _, color1, color2, opacity = GetPedHeadOverlayData(ped, i)
        hash = hash .. i .. (index or 0) .. (color1 or 0) .. (color2 or 0) .. (opacity or 0.0)
    end

    -- 3. Props (Hat, Glasses, Ears)
    for i = 0, 2 do
        hash = hash .. i .. GetPedPropIndex(ped, i) .. GetPedPropTextureIndex(ped, i)
    end

    -- 4. Hair and Model
    hash = hash .. GetEntityModel(ped) .. GetPedDrawableVariation(ped, 2) .. GetPedTextureVariation(ped, 2)

    return hash
end

-- ============================================================
-- SMART WATCHER LOOP
-- ============================================================

CreateThread(function()
    -- Wait for player to load
    while true do
        local pData = QBCore.Functions.GetPlayerData()
        if pData and pData.citizenid then break end
        Wait(1000)
    end
    
    Wait(5000) -- Extra delay to ensure appearance is applied
    
    while true do
        local pData = QBCore.Functions.GetPlayerData()
        if pData and pData.citizenid then
            local currentHash = GetAppearanceHash()
            
            if lastAppearanceHash == nil then
                -- Initial login capture
                lastAppearanceHash = currentHash
                CaptureFaceSilent()
            elseif lastAppearanceHash ~= currentHash then
                -- Appearance changed
                lastAppearanceHash = currentHash
                Wait(3000) -- Wait for animations to finish
                CaptureFaceSilent()
            end
        end
        Wait(10000) -- Check for changes every 10 seconds
    end
end)

-- ============================================================
-- SCREENSHOT CAPTURE WITH RATE LIMITING AND QUALITY
-- ============================================================

local function TakeScreenshotWithQuality(quality)
    local now = GetGameTimer()
    -- Silently capture - no F8 message to avoid spamming chat

    lastScreenshotTime = now

    local screenshotBasic = GetResourceState('screenshot-basic')
    local pData = QBCore.Functions.GetPlayerData()
    local cid = pData and pData.citizenid or "unknown"
    local playerName = pData and pData.charinfo and pData.charinfo.firstname and (pData.charinfo.firstname .. " " .. pData.charinfo.lastname) or GetPlayerName(PlayerId()) or cid

    if screenshotBasic == 'started' or screenshotBasic == 'starting' then
        -- Quality settings: low for live, high for manual
        local encodingQuality = quality == 'low' and (Config.ScreenshotQuality or 40) or 90
        local resolution = quality == 'low' and 0.5 or 1.0

        exports['screenshot-basic']:requestScreenshotUpload(Config.BackendURL .. '/api/server/0/upload-screenshot', 'file', {
            headers = {
                ['target-id'] = cid,
                ['player-name'] = playerName
            },
            encoding = 'jpg',
            quality = encodingQuality
        }, function(data)
            -- Silently succeed - no F8 message to avoid chat spam
        end)
    else
        -- Fallback to face portrait if screenshot-basic is missing
        CaptureFaceSilent()
        print("^3[Shefra Sync] ^7screenshot-basic not found. Falling back to face portrait.")
    end
end

-- ============================================================
-- ADMIN ACTIONS HANDLERS
-- ============================================================

RegisterNetEvent('shefra:client:TeleportToCoords', function(coords)
    local ped = PlayerPedId()
    local x, y, z = coords.x, coords.y, coords.z
    if not z then x, y, z = coords[1], coords[2], coords[3] end
    
    DoScreenFadeOut(500)
    Wait(500)
    SetEntityCoords(ped, x, y, z, false, false, false, false)
    Wait(500)
    DoScreenFadeIn(500)
end)

RegisterNetEvent('shefra:client:SetFreeze', function(freeze)
    FreezeEntityPosition(PlayerPedId(), freeze)
end)

RegisterNetEvent('shefra:client:ToggleCuff', function()
    local ped = PlayerPedId()
    if not IsPedCuffed(ped) then
        RequestAnimDict("mp_arresting")
        while not HasAnimDictLoaded("mp_arresting") do Wait(10) end
        TaskPlayAnim(ped, "mp_arresting", "idle", 8.0, -8, -1, 49, 0, 0, 0, 0)
        SetEnableHandcuffs(ped, true)
    else
        ClearPedTasks(ped)
        SetEnableHandcuffs(ped, false)
    end
end)

RegisterNetEvent('shefra:client:RepairVehicle', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle ~= 0 then
        SetVehicleFixed(vehicle)
        SetVehicleDirtLevel(vehicle, 0.0)
        SetVehicleEngineHealth(vehicle, 1000.0)
        SetVehicleBodyHealth(vehicle, 1000.0)
        SetVehiclePetrolTankHealth(vehicle, 1000.0)
    end
end)

RegisterNetEvent('shefra:client:SetWeather', function(weather)
    SetWeatherTypeOvertimePersist(weather, 15.0)
    SetWeatherTypeNowPersist(weather)
end)

RegisterNetEvent('shefra:client:SetTime', function(hour, minute)
    NetworkOverrideClockTime(hour, minute, 0)
end)

-- High-quality manual screenshot
RegisterNetEvent('shefra:client:TakeScreenshot', function(targetId)
    TakeScreenshotWithQuality('high')
end)

-- Low-quality live screenshot (for auto-capture)
RegisterNetEvent('shefra:client:TakeLiveScreenshot', function(targetId)
    TakeScreenshotWithQuality('low')
end)

-- ============================================================
-- STASH PROP SPAWNER - Creates vault objects at locations
-- ============================================================
local spawnedStashProps = {}

RegisterNetEvent('shefra:client:SpawnStashProp', function(stashData)
    local model = stashData.model or 'prop_drop_3setbox'
    local coords = stashData.coords
    local stashName = stashData.stashName
    local slots = stashData.slots or 20
    local allowedCids = stashData.allowedCids or {}
    local password = stashData.password or ''
    
    if not coords or not coords.x then return end
    
    -- Load the model
    local modelHash = GetHashKey(model)
    RequestModel(modelHash)
    local timeout = 5000
    while not HasModelLoaded(modelHash) and timeout > 0 do
        Wait(100)
        timeout = timeout - 100
    end
    
    if not HasModelLoaded(modelHash) then return end
    
    -- Check if prop already exists at this location for this stash
    if spawnedStashProps[stashName] then
        -- Already spawned, skip
        SetModelAsNoLongerNeeded(modelHash)
        return
    end
    
    -- Create the prop
    local prop = CreateObject(modelHash, coords.x, coords.y, coords.z, false, false, false)
    SetEntityAsMissionEntity(prop, true, true)
    FreezeEntityPosition(prop, true)
    SetEntityInvincible(prop, true)
    
    -- Store reference
    spawnedStashProps[stashName] = {
        entity = prop,
        model = model,
        coords = coords,
        slots = slots,
        allowedCids = allowedCids,
        password = password
    }
    
    SetModelAsNoLongerNeeded(modelHash)
end)

-- Target system integration: Register stash props for interaction
CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local pedCoords = GetEntityCoords(ped)
        
        for stashName, stashInfo in pairs(spawnedStashProps) do
            if stashInfo.entity and DoesEntityExist(stashInfo.entity) then
                local propCoords = GetEntityCoords(stashInfo.entity)
                local dist = #(pedCoords - propCoords)
                
                if dist < 3.0 then
                    -- Close enough to interact - trigger target system
                    -- This works with qb-target / ox_target
                    local targetResource = GetResourceState('qb-target')
                    local oxTargetResource = GetResourceState('ox_target')
                    
                    if targetResource == 'started' then
                        -- qb-target integration handled via export on spawn
                    elseif oxTargetResource == 'started' then
                        -- ox_target integration handled via export on spawn
                    end
                end
            end
        end
    end
end)

-- ============================================================
-- NUI CALLBACKS
-- ============================================================

RegisterNUICallback('avatar_upload_done', function(data, cb)
    if data and data.url and data.citizenid then
        TriggerServerEvent('shefra:server:UpdateAvatarMemory', data.citizenid, data.url)
    end
    cb('ok')
end)

RegisterNetEvent('shefra:client:RequestFaceCapture', function()
    CaptureFaceSilent()
end)
