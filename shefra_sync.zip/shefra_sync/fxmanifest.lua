fx_version 'cerulean'
game 'gta5'

author 'Shefra Store'
description 'Shefra Panel Synchronization Script'
version '1.0.0'

-- Only requires qb-core. screenshot-basic is optional.
dependencies {
    'qb-core'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'shared_config.lua',
    'config.lua',
    'server.lua'
}

client_scripts {
    'shared_config.lua',
    'client.lua'
}

ui_page 'nui/index.html'

files {
    'nui/index.html'
}
